<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <link rel="stylesheet" href="final.css">
</head>
<body>
     <div id="container">
       
  <div class="steam" id="steam1"> </div>
  <div class="steam" id="steam2"> </div>
  <div class="steam" id="steam3"> </div>
  <div class="steam" id="steam4"> </div>

  <div id="cup">
    <div id="cup-body">
        <h2 class="text">THANK YOU!! </h2>
        <p class= "text">It was great to have you here</p>
        <a class="text" href="http://localhost/movie">Back To Dashboard</a>
      <div id="cup-shade"></div>
    </div>
    <div id="cup-handle"></div>
  </div>

  <div id="saucer"></div>

  <div id="shadow"></div>
</div>
</body>
</html>